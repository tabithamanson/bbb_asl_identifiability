These scripts call on FMRIB FSL tools including oxford_asl v.3.9.17.

1) main_preprocessing.sh:
	mcflirt, topup, hadamard decoding, oxford_asl, asl_calib

2) main_preprocessing_10rep_participant.sh:
	same as above but for the 10 repeat participant.
	
3) run_oxford_asl.sh:
	Just the oxford ASL step, but this time using just the first TE from the long TI (3.1 s). 
	Need to run main_preprocessing.sh first.

4) calibrate_by_M0a_alpha.sh:
	Final calibration step for CBF maps (divide by labelling efficiency)

5) make_average_TI1_TE1.sh:
	For making maps of the arterial signal using the first data point (TI 1.1s, TE 21 ms).
	
6) make_Lweighted_images.sh:
	Preprocessing for the T2_EES monoexponential fit. Adds together the Hadamard-encoded images.
	
7) my_b02b0.cnf:
	Custom config file for topup. Based on visual assessment of topup outcome + parameter tweaking.
	
8) my_topup_acquisition_parameters.txt:
	Also for topup. Based on the acquisition parameters of the DPRCX data.
	
