#!/bin/sh
#FOR PILOT SUBJECT WITH 10 REPEATS (. Post-ISMRM-abstract WIP. Update since last version: mcflirt and topup applied to HE images before decoding. 

#################################### PART A hadamard decode ###################################
#For decoding the DPRCX hadamard-encoded data. Takes 4D hadamard-encoded .nii files (BAT and rep1 & rep2), performs distortion correction and motion correction and then decodes them.

# STEP 1: get all the series numbers (and filenames) for BAT, multi-TE rep1, multi-TE rep2, and M0 (ssRL & ssLR) scans
# STEP 2: MCFLIRT: motion correct (MCFLIRT) each of the encoded series (1st vol of BAT is refvol). 
# STEP 3: Distortion corresction: calculate topup transform between M0 RL & LR images. Apply to all other h-encoded images..
# STEP 4: split up the hadamard-encoded 4D .nii volume into individual encoded images (4 volumes per echo)
# STEP 5: Decode all of the h-encoded images.
# STEP 6: Combine decoded BAT images into 1 4D volume, combine rep1 & rep 2 into 1 4D volume

################################# PART B oxford asl and aslcalib ###############################

# STEP 7: oxford ASL
# STEP 8: ASL-calib

echo setting paths
script_basename=$(basename $0)
script_name=$(pwd)/$0
echo script_basename is $script_basename
echo script_name is $script_name
cd /
sourcedir=/data2/DPRCX_PILOT/sourcedata
derivativesdir=/data2/DPRCX_PILOT/derivatives/tabitha_processing
my_asl_calib=/data/USERS/CATHERINE/ASL_TESTING/FSL_ASL_TESTING/oxford_asl/asl_calib #/data/SOFTWARE/fsl_v6.0.3/bin/asl_calib
topup_acquisition_parameters=/data2/USERS/tman776/scripts/my_topup_acquisition_parameters
alpha=0.85
echoes=(1 2 3 4 5 6 7)
subject_list=$(ls $sourcedir)
#subject_list=$(find -H -maxdepth 1 -type d -name 'sub*' -printf '%f\n') #try this out
run_name=chapter_2_TM_thesis_run5
fslanatdir=/data2/DPRCX_BIDS/derivatives/FSL_ANAT
repeats=10
#force_preprocessing="FALSE" # "TRUE" or "FALSE" - n.b. this option doesnt work yet

subject_list=(sub-DPRCXPILOT14) # the participant with 10 repeats

for subject in ${subject_list[@]}; do

	mkdir ${derivativesdir}/${subject}/ 
	mkdir ${derivativesdir}/${subject}/asl_pilot
	#if [ -d ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/ ]; then
	if 0; then
		echo ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/ already exists... skipping this subject.
	else
		mkdir ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/
		subj_outdir=${derivativesdir}/${subject}/asl_pilot
		logfile=$derivativesdir/${subject}/asl_pilot/whole_pipeline_DPRCX_${run_name}
		echo whole_pipeline_DPRCX_${run_name} > $logfile
		date >> $logfile
		echo script name is $script_name > $logfile
		echo processing ${subject} >> $logfile
		script_copy_dir=${subj_outdir}
		cp $script_name $script_copy_dir/${run_name}_${script_basename}
		
		cd ${sourcedir}
		# make an array of all the BAT scan series numbers and store in array BATnums
	
		BAT_array=$(ls ${subject}/asl/*_BAT_1_*.nii)
		j=0;
		for i in ${BAT_array[@]}; do BATnums_unsorted[$j]=$(echo $i | cut -d "_" -f 7); 
		j=$(($j+1))
		echo $j; done
		BATnums_sorted_string=$(echo ${BATnums_unsorted[@]} | tr " " "\n" | sort -g)
		j=0;
		while [ ${j} -le 7 ] 
		do 
		BATnums_sorted[$j]=$(echo ${BATnums_sorted_string[@]} | cut -d " " -f $(($j+1)))  
		j=$(($j+1))
		done

		echo BATnums_sorted ${BATnums_sorted[@]}
		#BATnum1=$(echo $BATnums_sorted | cut -d " " -f 1)
		BATnum1=${BATnums_sorted[0]}
		#BATnums=($(($BATnum1 + 2))  $(($BATnum1 + 3)) $(($BATnum1 + 4)) $(($BATnum1 + 5)) $(($BATnum1 + 6)) $(($BATnum1 + 7)) $(($BATnum1 + 8)))
		#BATnums=$(echo $BATnums_sorted | cut -d " " -f 2-7)
		BATnums=${BATnums_sorted[@]:1}
		echo BATnums ${BATnums[@]}
		#for subject 0111F1:
		#BATnums=(56 57 58 59 60 61 62)

		# make an array of all the multi-echo, multi-TI ("rep1") scan series sumbers and store in array rep1nums. Same for rep2 etc
		rep1_array=$(ls "${subject}"/asl/*rep1_*.nii)
		j=0;
		for i in "${rep1_array[@]}"; do rep1nums_unsorted[$j]=$(echo "$i" | cut -d _ -f 8); j=$(($j+1)); done
		rep1nums_sorted_string=$(echo ${rep1nums_unsorted[@]} | tr " " "\n" | sort -g)
		j=0;
		while [ ${j} -le 28 ] 
		do 
		rep1nums_sorted[$j]=$(echo ${rep1nums_sorted_string[@]} | cut -d " " -f $(($j+1))) 
		j=$(($j+1))
		done
		echo rep1nums_sorted ${rep1nums_sorted[@]}
		rep1num1=${rep1nums_sorted[0]}
		rep1nums=(${rep1nums_sorted[7]} ${rep1nums_sorted[14]} ${rep1nums_sorted[21]})
		#rep1num1=$(echo $rep1nums_sorted | cut -d " " -f 1)
		#rep1nums=$(echo $rep1nums_sorted | cut -d " " -f 8,15,22)
	
		echo rep1nums ${rep1nums[@]}
		
		HE_num=${rep1num1}
		k=2;
		while [ ${k} -le $repeats ] ; do
		HE_num[$k-1]=$((${rep1num1} + 6*(${k}-1)))
		k=$(($k+1));
		done
		echo HE_num ${HE_num[@]} >> $logfile

		rep2_array=$(ls "${subject}"/asl/*rep2*.nii)
		j=0;
		for i in "${rep2_array[@]}"; do rep2nums_unsorted[$j]=$(echo "$i" | cut -d _ -f 8); j=$(($j+1)); done
		rep2nums_sorted_string=$(echo ${rep2nums_unsorted[@]} | tr " " "\n" | sort -g)
		j=0;
		while [ ${j} -le 28 ] 
		do 
		rep2nums_sorted[$j]=$(echo ${rep2nums_sorted_string[@]} | cut -d " " -f $(($j+1)));
		j=$(($j+1))
		done
		echo rep2nums_sorted ${rep2nums_sorted[@]}
		rep2num1=${rep2nums_sorted[0]}
		rep2nums=(${rep2nums_sorted[7]} ${rep2nums_sorted[14]} ${rep2nums_sorted[21]})

		#rep2num1=$(echo $rep2nums_sorted | cut -d " " -f 1)
		#rep2nums=$(echo $rep2nums_sorted | cut -d " " -f 8,15,22)
	echo rep2nums ${rep2nums[@]}
	
	
		#rep2nums=($(($rep1num1 + 8)) $(($rep1num1 + 9)) $(($rep1num1 + 10)))
		#rep2num1=($(($rep1num1 + 6)))
######### 	
		# make an array of all the M0 scan series numbers and store in array ssRLnums. Same for the phase-encode reversed M0 images 	# (ssLRnums).	
		M0_array=$(ls "${subject}"/asl/*ss*.nii)
		j=0;
		for i in "${M0_array[@]}"; do M0nums_unsorted[$j]=$(echo "$i" | cut -d _ -f 6); j=$(($j+1)); done
		M0nums_sorted=$(echo ${M0nums_unsorted[@]} | tr " " "\n" | sort -g)
		echo M0nums_sorted $M0nums_sorted
		M0num1=$(echo $M0nums_sorted | cut -d " " -f 1)
		ssRLnums_string=$(echo $M0nums_sorted | cut -d " " -f 1-3)
		ssLRnums_string=$(echo $M0nums_sorted | cut -d " " -f 4-6)
		j=0;
		while [ ${j} -le 2 ] 
		do 
		ssRLnums[$j]=$(echo ${ssRLnums_string[@]} | cut -d " " -f $(($j+1))) 
		ssLRnums[$j]=$(echo ${ssLRnums_string[@]} | cut -d " " -f $(($j+1)))
		j=$(($j+1))
		done
		#
		#ssRLnums=($(($M0num1)) $(($M0num1 + 1)) $(($M0num1 + 2)))
		#ssLRnums=($(($M0num1 + 3)) $(($M0num1 + 4)) $(($M0num1 + 5)))

		#For subject 0097F2:
		#ssRLnums=(58 59 60)
		#ssLRnums=(43 44 45)
		#M0num1=58

		# if the rest of the script throws missing image file errors, check these against the image names in the source directory:	
		echo ---------------------------------
		echo BAT series numbers ${BATnums[@]} >> $logfile
		echo rep1 series numbers ${rep1nums[@]} >> $logfile
		echo rep2 series numbers ${rep2nums[@]} >> $logfile
		echo ss RL series numbers ${ssRLnums[@]} >> $logfile
		echo ss LR series numbers ${ssLRnums[@]} >> $logfile
		echo Starting subject ${subject} in source directory: ${sourcedir} >> $logfile
		echo -----------------------------------
	# STRUCTURAL ANALYSIS FIRST:
		cd /
#		if [ -e ${subj_outdir}/BASIL_output_${run_name}/struc.anat/T1.nii.gz ]; then
#		rm -r ${subj_outdir}/BASIL_output_${run_name}/*
#		fi
		/data/SOFTWARE/fsl/bin/fsl_anat -i "${sourcedir}/${subject}/anat/${subject}_T1w.nii" -o "${subj_outdir}/BASIL_output_${run_name}/struc"
		#/data/SOFTWARE/fsl/bin/fsl_anat -d "${fslanatdir}/${subject}/struc.anat" -o "${subj_outdir}/BASIL_output_${run_name}/struc"

######################## FSL ANAT STEP ################################

		##if [ -d "${fslanatdir}/${subject}/struc.anat" ]; then
		##	echo FSL_ANAT exists here\: "${fslanatdir}/${subject}/struc.anat/" >> $logfile
			##subject_fslanat_dir=${fslanatdir}/${subject}/struc.anat >> $logfile
		##else
#			echo FSL_ANAT directory does not exist. Running FSL ANAT. >> $logfile
#			/data/SOFTWARE/fsl/bin/fsl_anat -i "${sourcedir}/${subject}/anat/${subject}_T1w.nii" --clobber -o "${subj_outdir}/BASIL_output_${run_name}/struc" >> $logfile
			subject_fslanat_dir=${subj_outdir}/BASIL_output_${run_name}/struc.anat >> $logfile
		##fi
		
##########################################################################

	echo \make a dilated brain mask from T1_biascorr_brain to use \for masking ASL images. #Dilated so that movement doesn't matter 
	dil=10 # voxels 
	j=2;
	fslmaths ${subject_fslanat_dir}/T1_biascorr_brain_mask.nii.gz -dilM -kernel 3D ${subj_outdir}/T1_biascorr_brain_mask_dil1.nii.gz
	while [ ${j} -le ${dil} ] 
		do 
		fslmaths "${subj_outdir}/T1_biascorr_brain_mask_dil$(($j-1)).nii.gz" -dilM -kernel 3D ${subj_outdir}/T1_biascorr_brain_mask_dil${j}.nii.gz
		rm "${subj_outdir}/T1_biascorr_brain_mask_dil$(($j-1)).nii.gz"
		j=$(($j+1))
	done
	
	#-------------------------------------- PART A ----------------------------------------------------
	###############################################################################################################################
	echo STEP 1: get all the series numbers \(and filenames\) \for BAT, multi-TE rep1, multi-TE rep2, and M0 \(ssRL \& ssLR\) scans >> $logfile
	
		cd ${sourcedir}
	###########################################################################################################################
	# PRE-PROCESSING : TOPUP AND MOTION CORRECTION
	
	#Skip pre-processing if topup and mc have already been done
	#if [[ ( ! -e "${subj_outdir}/${subject}_C_fme_pCASL_ME_*_topup_brain_mcf.nii.gz" ) && (${force_preprocessing}="TRUE") ]]; then
	#if [ ! -e "${subj_outdir}/HE_betted_mcf_topup/*_brain_mcf_topup.nii.gz" ]; then #skip mcf and topup if already done: this doesn't seem to work yet
	if [ 1 ] ; then
				##################################################################################################################################
		echo STEP 2: motion correct \(MCFLIRT\) each of the encoded series \(1st vol of BAT is refvol\). >> $logfile	
	
		echo splitting 4D encoded .nii image into hadamard-encoded \(HE\) volumes \for each \echo
		rm -r ${subj_outdir}/*HE*
		echoes=(1 2 3 4 5 6 7)
		r=1;
		while [ ${r} -le ${repeats} ]; do
			for te in ${echoes[@]}; do	
				pwd
					fslsplit ${subject}/asl/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}.nii ${subj_outdir}/rep${r}_${HE_num[${r}-1]}_${te}_HE -t
					#fslsplit ${subject}/asl/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}.nii ${subj_outdir}/rep2_${rep2num1}_${te}_HE -t
			done
			r=$((${r}+1))
		done
		fslsplit ${subject}/asl/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_1.nii ${subj_outdir}/BAT_${BATnum1}_HE -t

		echo BET everything and recombine. #BET should be performed before FLIRT https://fsl.fmrib.ox.ac.uk/fsl/fslwiki/FLIRT/FAQ#My_FLIRT_registration_doesn.27t_work_well_-_what_can_I_do.3F	
		mkdir ${subj_outdir}/HE_betted/
		
		HE_BAT_images=(${subj_outdir}/BAT*HE*)
		echo HE_BAT_image 0 = "${HE_BAT_images[0]}"
		bet ${HE_BAT_images[0]} ${subj_outdir}/BAT_brain.nii.gz -m -f 0.55 #needs to be a little tighter than default to get rid of artifacts
		# IN THIS VERSION I"M USING THE FSL ANAT MASK DILATED AND DOWNSAMPLED INTO ASL SPACE
		flirt -in ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}.nii.gz -ref ${subj_outdir}/BAT_brain.nii.gz -out ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}_inasl.nii.gz -applyxfm -usesqform -interp nearestneighbour
		
		for HE_im in ${HE_BAT_images[@]} ; do	
			echo HE_BAT_image[] = ${HE_im}
			#fslmaths ${HE_im} -mas ${subj_outdir}/HE_betted/BAT_brain_mask.nii.gz ${HE_im}_brain
			fslmaths ${HE_im} -mas ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}_inasl.nii.gz ${HE_im}_brain
		done
		fslmerge -t ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain ${subj_outdir}/BAT*HE*_brain*
		#cp "${HE_BAT_images[0]}" ${subj_outdir}/BAT_control.nii.gz
		#fslmaths ${subj_outdir}/BAT_control.nii.gz -mas ${subj_outdir}/BAT_brain_mask ${subj_outdir}/BAT_control_brain.nii.gz 
		r=1;
		while [ ${r} -le ${repeats} ]; do
			HE_rep_ME_images=(${subj_outdir}/rep${r}_*HE*)
			bet ${HE_rep_ME_images[0]} ${subj_outdir}/rep${r}_brain.nii.gz -m -f 0.55
			for HE_im in ${HE_rep_ME_images[@]}; do
				#fslmaths ${HE_im} -mas ${subj_outdir}/HE_betted/rep1_brain_mask ${HE_im}_brain
				fslmaths ${HE_im} -mas ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}_inasl.nii.gz ${HE_im}_brain
			done
			r=$((${r}+1))
		done

		#HE_rep2_ME_images=(${subj_outdir}/rep2*HE*)
		#bet ${HE_rep2_ME_images[0]} ${subj_outdir}/rep2_brain.nii.gz -m -f 0.55
		#for HE_im in ${HE_rep2_ME_images[@]}; do
	#		#fslmaths ${HE_im} -mas ${subj_outdir}/HE_betted/rep2_brain_mask ${HE_im}_brain
	#		fslmaths ${HE_im} -mas ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}_inasl.nii.gz ${HE_im}_brain
	#	done
	
	r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			fslmerge -t ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain ${subj_outdir}/*rep${r}_*_${te}_HE*_brain*
			#fslmerge -t ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain ${subj_outdir}/*rep2*_${te}_HE*_brain*
		done
		r=$((${r}+1));
	done
		#rm -r ${subj_outdir}/*HE*

		mkdir ${subj_outdir}/HE_betted_mcf/
		# motion correction, reffile is the first (0th) volume (control) from the BAT scan.
		mcflirt -in ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain -refvol 0 -out ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain_mcf.nii.gz -report -rotation 2 -smooth 4 -stages 5
	
	r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			mcflirt -in ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain -reffile ${subj_outdir}/BAT*HE0000*_brain* -out ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain_mcf.nii.gz -report -rotation 2 -smooth 4 -stages 5

			#mcflirt -in ${subj_outdir}/HE_betted/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain -reffile ${subj_outdir}/BAT*HE0000*_brain* -out ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain_mcf.nii.gz -report -rotation 2 -smooth 4 -stages 5
		done
		r=$((${r}+1));
	done
		
		rm -r ${subj_outdir}/HE_betted/ #don't need to keep all the betted pre-processsed images
		
			
		echo STEP 3: Distortion-correction: calculate topup transform between M0 RL \& LR images. Apply to all other h-encoded images. >> $logfile
		# using pre-bet imaged as per topup user guide https://fsl.fmrib.ox.ac.uk/fsl/fslwiki/topup/TopupUsersGuide#Running_topup
			
		mkdir ${subj_outdir}/HE_betted_mcf_topup/
		mkdir ${subj_outdir}/topup_files/
			
		echo merging RL and LR M0 ims \for distortion correction \(topup\)
			#echo ls ${subject}/asl/${subject}_ss_TE00_TI*_${ssRLnums[0]}_1.nii*
		fslmerge -t ${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D.nii.gz \
				${subject}/asl/${subject}_ss_TE00_TI*_${ssRLnums[0]}_1.nii* \
			  	${subject}/asl/${subject}_ss_TE00_TI*_${ssRLnums[1]}_1.nii* \
				${subject}/asl/${subject}_ss_TE00_TI*_${ssRLnums[2]}_1.nii* \
			 	${subject}/asl/${subject}_ss_TE00_TI*_${ssLRnums[0]}_1.nii* \
				${subject}/asl/${subject}_ss_TE00_TI*_${ssLRnums[1]}_1.nii* \
				${subject}/asl/${subject}_ss_TE00_TI*_${ssLRnums[2]}_1.nii* \
	
		echo correct motion \in M0 RLLR series \(register to middle RL image\) >> $logfile
		mcflirt -in ${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D -refvol 1 -out ${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D_mcf.nii.gz -report

		echo perform FSL topup >> $logfile
		/data/SOFTWARE/fsl/bin/topup --imain=${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D_mcf.nii.gz --datain=${topup_acquisition_parameters}.txt --config=/data2/USERS/tman776/scripts/my_b02b0.cnf --out=${subj_outdir}/topup_files/${subject}_topup_out --iout=${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D_mcf_topup.nii.gz >> $logfile

		echo apply topup to all of the h-encoded images
		applytopup -i ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain_mcf.nii.gz -t ${subj_outdir}/topup_files/${subject}_topup_out -x 1 -a ${topup_acquisition_parameters}.txt -m jac -o ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain_mcf_topup.nii.gz >> $logfile

		r=1;
		while [ ${r} -le ${repeats} ]; do
			for te in ${echoes[@]} ; do
				applytopup -i ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain_mcf.nii.gz -t ${subj_outdir}/topup_files/${subject}_topup_out -x 1 -a ${topup_acquisition_parameters}.txt -m jac -o ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain_mcf_topup.nii.gz -v >> $logfile
				#applytopup -i ${subj_outdir}/HE_betted_mcf/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain_mcf.nii.gz -t ${subj_outdir}/topup_files/${subject}_topup_out -x 1 -a ${topup_acquisition_parameters}.txt -m jac -o ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain_mcf_topup.nii.gz -v >> $logfile
			done
			r=$((${r}+1));
		done
	else
		echo preprocessing has already been \done \for \this subject, skipping topup and mcf.  >> $logfile
	fi
		
	echo now that BAT images are unwarped, register BAT control image to T1_biascorr_brain to get linear asl2struc and struc2asl transforms
		
	fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain_mcf_topup.nii.gz ${subj_outdir}/BAT_${BATnum1}_brain_mcf_topup_HE -t
	HE_BAT_brain_mcf_topup_images=(${subj_outdir}/BAT_*_brain_mcf_topup_HE*)
	cp "${HE_BAT_brain_mcf_topup_images[0]}" ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control.nii.gz
	bet ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control.nii.gz ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control_brain.nii.gz -m -f 0.05 #conservative this time - just to get rid of background stuff from topup
	#fslmaths ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control.nii.gz -bin ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control_mask.nii.gz 
	flirt -in ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control.nii.gz -ref ${subject_fslanat_dir}/T1_biascorr_brain.nii.gz -out ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control_inT1.nii.gz -omat ${subj_outdir}/my_asl2struc.mat -dof 9 #doesn't work very well at the moment
		
	convert_xfm -omat ${subj_outdir}/my_struc2asl.mat -inverse ${subj_outdir}/my_asl2struc.mat
		
	#echo transforming T1_biascorr_brain into asl space
	#flirt -in ${subject_fslanat_dir}/T1_biascorr_brain.nii.gz -ref ${subj_outdir}/HE_betted_mcf_topup/BAT_brain_mcf_topup_control.nii.gz -out ${subj_outdir}/T1_biascorr_brain_inasl.nii.gz -init my_struc2asl.mat -applyxfm

	#echo making a generous mask from T1 biascorr brain \in asl space
	#fslmaths ${subj_outdir}/T1_biascorr_brain_inasl.nii.gz -thr 0.7 -bin ${subj_outdir}/T1_biascorr_brain_mask_inasl_thr07.nii.gz
		
	##################################################################################################################################
	echo STEP 4: \split up the hadamard-encoded 4D .nii volume into individual encoded images \(4 volumes per echo\) >> $logfile

	echo splitting 4D encoded .nii image into hadamard-encoded \(HE\) volumes \for each \echo
		echoes=(1 2 3 4 5 6 7)
		r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			echo te=$te
			fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep${r}_${HE_num[${r}-1]}_${te}_HE -t
			#fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep${r}_1_${rep2num1}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep${r}_${rep2num1}_${te}_HE -t
		done
		r=$((${r}+1));
	done
	fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_BAT_1_${BATnum1}_brain_mcf_topup.nii.gz ${subj_outdir}/BAT_${BATnum1}_HE -t

	##################################################################################################################################
	echo STEP 5: Decode all of the h-encoded images. >> $logfile
	
	mkdir ${subj_outdir}/decoded_betted_mcf_topup/
	
	#echo saving control images \for each ME ASL \echo as ${subj_outdir}/HE_betted_mcf_topup/ME_pCASL_rep1_rep2_HE_num
		#fslmerge -t ${subj_outdir}/HE_betted_mcf_topup/ME_pCASL_rep1_rep2_HE_num ${subj_outdir}/rep1_${rep1num1}_*_HE0000.nii.gz ${subj_outdir}/rep2_${rep2num1}_*_HE0000.nii.gz 

	echo BAT positive\(HE0 - HE1 + HE2 - HE3 + HE4 - HE5 + HE6 -HE7\)/4 = TI 1
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI1.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI1.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI1.nii.gz

	echo BAT positive\(HE0 + HE1 - HE2 - HE3 + HE4 + HE5 - HE6 -HE7\)/4 = TI 5
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI5.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI5.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI5.nii.gz

	echo BAT positive\(HE0 - HE1 - HE2 + HE3 + HE4 - HE5 - HE6 +HE7\)/4 = TI 4
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI4.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI4.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI4.nii.gz

	echo BAT positive\(HE0 + HE1 + HE2 + HE3 - HE4 - HE5 - HE6 -HE7\)/4 = TI 7
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI7.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI7.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI7.nii.gz

	echo BAT positive\(HE0 - HE1 + HE2 - HE3 - HE4 + HE5 - HE6 +HE7\)/4 = TI 2
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI2.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI2.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI2.nii.gz

	echo BAT positive\(HE0 + HE1 - HE2 - HE3 - HE4 - HE5 + HE6 +HE7\)/4= TI 6
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI6.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI6.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI6.nii.gz


	echo BAT positive\(HE0 - HE1 - HE2 + HE3 - HE4 + HE5 + HE6 -HE7\)/4 = TI 3
	fslmaths ${subj_outdir}/BAT_${BATnum1}_HE*00.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*01.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*02.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*03.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*04.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*05.nii.gz \
		-add ${subj_outdir}/BAT_${BATnum1}_HE*06.nii.gz \
		-sub ${subj_outdir}/BAT_${BATnum1}_HE*07.nii.gz \
		${subj_outdir}/decoded_betted_mcf_topup/BAT_TI3.nii.gz
	fslmaths ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI3.nii.gz -thr 0 -div 4 ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI3.nii.gz


	echo multi-te positive\(HE0 - HE1 + HE2 - HE3\)/2 = TI 1
	r=1;
	while [ ${r} -le ${repeats} ]; do
	for te in ${echoes[@]}; do
	fslmaths ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*00.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*01.nii.gz \
				-add ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*02.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*03.nii.gz \
				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI1_TE${te}.nii.gz
			fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI1_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI1_TE${te}.nii.gz
		done
		r=$((${r}+1));
	done

		#fslmaths ${subj_outdir}/rep2_${rep2num1}_${te}_HE*00.nii.gz \
		#	-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*01.nii.gz \
		#	-add ${subj_outdir}/rep2_${rep2num1}_${te}_HE*02.nii.gz \
		#	-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*03.nii.gz \
		#	${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI1_TE${te}.nii.gz
		#fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI1_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI1_TE${te}.nii.gz
	

	echo multi-te positive\(HE0 - HE1 - HE2 + HE3\)/2 = TI 2
	r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			fslmaths ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*00.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*01.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*02.nii.gz \
				-add ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*03.nii.gz \
				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI2_TE${te}.nii.gz
			fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI2_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI2_TE${te}.nii.gz

			#fslmaths ${subj_outdir}/rep2_${rep2num1}_${te}_HE*00.nii.gz \
				#-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*01.nii.gz \
				#-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*02.nii.gz \
				#-add ${subj_outdir}/rep2_${rep2num1}_${te}_HE*03.nii.gz \
				#${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI2_TE${te}.nii.gz
			#fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI2_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI2_TE${te}.nii.gz
		done
		r=$((${r}+1));
	done
	
	echo multi-te positive\(HE0 + HE1 - HE2 - HE3\)/2 = TI 3
	r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			fslmaths ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*00.nii.gz \
				-add ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*01.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*02.nii.gz \
				-sub ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*03.nii.gz \
				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI3_TE${te}.nii.gz
			fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI3_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI3_TE${te}.nii.gz

			#fslmaths ${subj_outdir}/rep2_${rep2num1}_${te}_HE*00.nii.gz \
			#	-add ${subj_outdir}/rep2_${rep2num1}_${te}_HE*01.nii.gz \
			#	-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*02.nii.gz \
			#	-sub ${subj_outdir}/rep2_${rep2num1}_${te}_HE*03.nii.gz \
			#	${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE${te}.nii.gz
			#fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE${te}.nii.gz -thr 0 -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE${te}.nii.gz
		done
		r=$((${r}+1));
	done
	
	#delete temp splitted HE files in sourcedir
	rm -r ${subj_outdir}/*HE00*
	
	r=1;
	while [ ${r} -le ${repeats} ]; do
	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI1_TE*.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI2_TE*.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_TI3_TE*.nii.gz
	r=$(($r+1))
	done
		
	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_allreps_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep*_4D.nii.gz

	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/BAT_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI*.nii.gz
		#delete split decoded volumes
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/BAT_TI*.nii.gz
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep?_TI1_TE*.nii.gz 
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep?_TI2_TE*.nii.gz 
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep?_TI3_TE*.nii.gz 
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep??_TI1_TE*.nii.gz
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep??_TI2_TE*.nii.gz 
	rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep??_TI3_TE*.nii.gz  
	#rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI1_TE*.nii.gz 
	#rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI2_TE*.nii.gz 
	#rm -r ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE*.nii.gz
	

	#-------------------------------------- PART B ----------------------------------------------------

	echo STEPS 7 \& 8\: oxford_asl, and asl_calib >> $logfile

		#/data/SOFTWARE/fsl/bin/fsl_anat -i "${sourcedir}/${subject}/anat/${subject}_T1w.nii" --clobber -o "${subj_outdir}/BASIL_output_${run_name}/struc"
		#/data/SOFTWARE/fsl/bin/fsl_anat -d "${fslanatdir}/${subject}/struc.anat" -o "${subj_outdir}/BASIL_output_${run_name}/struc"
		# NOTE CHANGE FROM ISMRM VERSION - CHANGED --tis to match actual TIs instead of PLDs (OLD: --tis 0.90,1.30,1.70,2.10,2.50,2.90,3.30)
		#if [ -d "${fslanatdir}/${subject}/struc.anat"]; then
			#echo FSL_ANAT exists here\: "${fslanatdir}/${subject}/struc.anat/"
			#echo temporarily copying to "${subj_outdir}/BASIL_output_${run_name}/struc.anat"
			#cp -R "${fslanatdir}/${subject}/struc.anat" "${subj_outdir}/BASIL_output_${run_name}/struc.anat"
		#fi
		
		
		# FSL_ANAT brain mask is in T1 (struc) space and - highres and aligned with the T1 image.
	
	echo Running oxford_asl....>> $logfile
	
		#
	#/data/SOFTWARE/fsl_v6.0.3/bin/oxford_asl
	# /data/SOFTWARE/fsl/bin/oxford_asl 
	/data/USERS/CATHERINE/ASL_TESTING/FSL_ASL_TESTING/oxford_asl/oxford_asl -i "${subj_outdir}/decoded_betted_mcf_topup/BAT_4D.nii.gz" --ibf=tis --iaf=diff --tis 0.50,0.90,1.30,1.70,2.10,2.50,2.90 --bolus 0.40 --casl --fslanat="${subject_fslanat_dir}" -m ${subj_outdir}/T1_biascorr_brain_mask_dil${dil}_inasl.nii.gz --t1 1.30 --bat 1.30 --t1b 1.65 --alpha 0.85 --fixbolus --spatial --infert1 --pvcorr --exch=2cpt -o "${subj_outdir}/BASIL_output_${run_name}" >> $logfile

	#  -c /data2/DPRCX_BIDS/sourcedata/${subjectdir}/asl/${subjectdir}_ss_TE00_TI*_${ssRLnums[1]}*.nii --tr 3.5 --cblip /data2/DPRCX_BIDS/sourcedata/${subjectdir}/asl/${subjectdir}_ss_TE00_TI*_${ssLRnums[1]}*.nii --pedir=x --echospacing=0.0005 

		# Calibrate using M0.txt (arterial equilibrium magnetisation from asl_calib)
	echo ASL calib satrecovery mode ... >> $logfile
	mkdir ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/

	$my_asl_calib -c ${subj_outdir}/topup_files/${subject}_ss_TE00_RLLR_4D_mcf_topup.nii.gz -s ${subj_outdir}/BASIL_output_${run_name}/struc.anat/T1_biascorr_brain.nii.gz -t ${subj_outdir}/BASIL_output_${run_name}/native_space/asl2struct.mat  --mode satrecov --te 20.54 --tis 0.5,1.7,2.9,0.5,1.7,2.9 --cgain 10 --tissref wm -m ${subj_outdir}/BASIL_output_${run_name}/native_space/wm_roi -o ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder >> $logfile


	echo calibrate using value in M0.txt \(note M0.txt is arterial equilibrium magnetisation\) >> $logfile
		
	#-div $alpha?

	fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvcorr/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_pvcorr_calib_wm_M0
	
	fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_M0
	 
	#NOTE BELOW HASBEENUPDATED FROMISMRM VERSION: -div .... /perfusion_calib_folder updated to:-div .../perfusion_calib_wm_folder
		#fslmaths ${subj_outdir}/${subjectdir}_C_fme_pCASL_ME_average_1_4D -div $alpha -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) ${subj_outdir}/${subjectdir}_C_fme_pCASL_ME_average_1_4D_calib_wm_M0a_alpha_av

	#binarise and threshold pvgm_inasl mask (coarse and fine masks):
		#fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvgm_inasl -thr 0.3 -bin ${subj_outdir}/pvgm_inasl_thr03

	fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvgm_inasl -thr 0.5 -bin ${subj_outdir}/pvgm_inasl_thr05

	echo main outputs are: >> $logfile
		#echo Multi-TE ASL data uncalibrated:     ${subj_outdir}/${subjectdir}_C_fme_pCASL_ME_average_1_4D
	echo perfusion uncalibrated: ${subj_outdir}/BASIL_output_${run_name}/native_space/pvcorr/perfusion.nii.gz >> $logfile
		#echo perfusion calibrated:    ${subj_outdir}/perfusion_calib_wm_M0a_alpha_av
	echo Arterial equilibrium magnetisation assuming alpha 0.85: ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt >> $logfile
	
	#ZIP UP HE IMAGES
	cd ${subj_outdir}
	tar -czf HE_intermediate_images.tar.gz HE_betted_mcf_topup HE_betted_mcf/
	rm -r HE_betted_mcf_topup
	rm -r HE_betted_mcf
	
		
	echo Finished ${subjectdir} preparation :\) >> $logfile
fi
echo ----------------------------------------------------------------------------------------------------
done

cd /

