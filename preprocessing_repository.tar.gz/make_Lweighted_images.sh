#!/bin/sh
# make label-weighted images from the ME-pCASL hadamard-encoded data (note it should already have been through topup and motion correction) and be stored in ${subj_outdir}/HE_betted_mcf_topup/
# These label-weighted images can then be used to fit for EES T2 
if [ ]; then
subject_list=(sub-ADPRCX0003F3
sub-ADPRCX0041F2
sub-ADPRCX0052F2
sub-ADPRCX0055F2
sub-ADPRCX0057F2
sub-ADPRCX0059F2
sub-ADPRCX0067F2
sub-ADPRCX0073F2
sub-ADPRCX0095F1
sub-ADPRCX0103F1
sub-ADPRCX0111F1
sub-ADPRCX0112F1
sub-ADPRCX0119F1
sub-ADPRCX0120F1
sub-ADPRCX0121F1
sub-ADPRCX0129F1
sub-ADPRCX0135F1
sub-ADPRCX0159F0
sub-ADPRCX0167F0
sub-ADPRCX0174F0
sub-ADPRCX0175F0
sub-ADPRCX0010F3
sub-ADPRCX0048F3
sub-ADPRCX0053F2
sub-ADPRCX0090F2
sub-ADPRCX0143F1
sub-ADPRCX0149F1
sub-ADPRCX0184F0
sub-ADPRCX0193F0
sub-ADPRCX0086F2
sub-ADPRCX0084F2
sub-ADPRCX0097F2
sub-ADPRCX0060F2
sub-ADPRCX0196F1
sub-ADPRCX0089F2
sub-ADPRCX0203F0
sub-ADPRCX0015F3
sub-ADPRCX0206F0
sub-ADPRCX0180F1
sub-ADPRCX0181F1
sub-ADPRCX0081F2
sub-ADPRCX0172F1
sub-ADPRCX0101F2
sub-ADPRCX0152F1
sub-ADPRCX0002F4
sub-ADPRCX0019F4
sub-ADPRCX0020F4
sub-ADPRCX0211F0
sub-ADPRCX0219F0
sub-ADPRCX0210F0
sub-ADPRCX0130F2
sub-ADPRCX0049F4
sub-ADPRCX0058F4
sub-ADPRCX0083F3
sub-ADPRCX0144F2
sub-ADPRCX0115F2
sub-ADPRCX0122F2
sub-ADPRCX0128F2
sub-ADPRCX0145F2
sub-ADPRCX0147F2
sub-ADPRCX0201F1
sub-ADPRCX0227F0
sub-ADPRCX0189F1
sub-ADPRCX0170F2
sub-ADPRCX0208F0
sub-ADPRCX0228F0
sub-ADPRCX0163F2
sub-ADPRCX0075F2
sub-ADPRCX0205F2
sub-ADPRCX0248F0
sub-ADPRCX0244F0
sub-ADPRCX0186F2
sub-ADPRCX0214F2
sub-ADPRCX0198F2
sub-ADPRCX0234F1
) #all subjects 
#subject_list=sub-ADPRCX0067F2
fi

pilot_subject=1
subject_list=sub-DPRCXPILOT14
derivativesdir=/data2/DPRCX_PILOT/derivatives/tabitha_processing
sourcedir=/data2/DPRCX_PILOT/sourcedata
#derivativesdir=/data2/DPRCX_BIDS/derivatives
#sourcedir=/data2/DPRCX_BIDS/sourcedata



repeats=10


for subject in ${subject_list[@]}; do
#subject_fslanat_dir=/data2/DPRCX_BIDS/derivatives/FSL_ANAT/${subject}/struc.anat
subject_fslanat_dir=/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot/BASIL_output_chapter_2_TM_thesis_run5/struc.anat


cd ${sourcedir}
rep1_array=$(ls "${subject}"/asl/*rep1*.nii)
				j=0;
				for i in "${rep1_array[@]}"; do rep1nums_unsorted[$j]=$(echo "$i" | cut -d _ -f 8); j+=1; done
				rep1nums_sorted_string=$(echo ${rep1nums_unsorted[@]} | tr " " "\n" | sort -g)
				j=0;
				while [ ${j} -le 28 ] 
				do 
				rep1nums_sorted[$j]=$(echo ${rep1nums_sorted_string[@]} | cut -d " " -f $(($j+1))) 
				j=$(($j+1))
				done
				echo rep1nums_sorted ${rep1nums_sorted[@]}
				rep1num1=${rep1nums_sorted[0]}
				rep1nums=(${rep1nums_sorted[7]} ${rep1nums_sorted[14]} ${rep1nums_sorted[21]})
				#rep1num1=$(echo $rep1nums_sorted | cut -d " " -f 1)
				#rep1nums=$(echo $rep1nums_sorted | cut -d " " -f 8,15,22)
	
				echo rep1nums ${rep1nums[@]}

				rep2_array=$(ls "${subject}"/asl/*rep2*.nii)
				j=0;
				for i in "${rep2_array[@]}"; do rep2nums_unsorted[$j]=$(echo "$i" | cut -d _ -f 8); j+=1; done
				rep2nums_sorted_string=$(echo ${rep2nums_unsorted[@]} | tr " " "\n" | sort -g)
				j=0;
				while [ ${j} -le 28 ] 
				do 
				rep2nums_sorted[$j]=$(echo ${rep2nums_sorted_string[@]} | cut -d " " -f $(($j+1))) 
				j=$(($j+1))
				done
				echo rep2nums_sorted ${rep2nums_sorted[@]}
				rep2num1=${rep2nums_sorted[0]}
				rep2nums=(${rep2nums_sorted[7]} ${rep2nums_sorted[14]} ${rep2nums_sorted[21]})

				#rep2num1=$(echo $rep2nums_sorted | cut -d " " -f 1)
				#rep2nums=$(echo $rep2nums_sorted | cut -d " " -f 8,15,22)
			echo rep2nums ${rep2nums[@]}
			cd ${derivativesdir}
	
	###
	HE_num=${rep1num1}
		k=2;
		while [ ${k} -le $repeats ] ; do
		HE_num[$k-1]=$((${rep1num1} + 6*(${k}-1)))
		k=$(($k+1));
		done
		echo HE_num ${HE_num[@]}
	###
	
	subj_outdir=${derivativesdir}/${subject}/asl_pilot
	cd ${subj_outdir}
	tar -xvzf HE_intermediate_images.tar.gz
	cd ${derivativesdir}
	echo STEP 4: \split up the hadamard-encoded 4D .nii volume into individual encoded images \(4 volumes per echo\) 
	echo splitting 4D encoded .nii image into hadamard-encoded \(HE\) volumes \for each \echo
	echoes=(1 2 3 4 5 6 7)
	#/data2/DPRCX_BIDS/derivatives/sub-ADPRCX0059F2/asl_pilot/HE_intermediate_images/HE_betted_mcf_topup/sub-ADPRCX0059F2_C_fme_pCASL_ME_rep1_1_31_1_brain_mcf_topup

	###
	r=1;
	while [ ${r} -le ${repeats} ]; do
		for te in ${echoes[@]}; do
			echo te=$te
			fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep${r}_1_${HE_num[${r}-1]}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep${r}_${HE_num[${r}-1]}_${te}_HE -t
			#fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep${r}_1_${rep2num1}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep${r}_${rep2num1}_${te}_HE -t
		done
		r=$((${r}+1));
	done
	
	echo multi-te positive\(HE1 + HE2 + HE3\) = 3c \| 2L+c \| 2L+c \|  
	
	r=1;
	while [ ${r} -le ${repeats} ]; do
	for te in ${echoes[@]}; do
	fslmaths 	${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*01.nii.gz \
				-add ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*02.nii.gz \
				-add ${subj_outdir}/rep${r}_${HE_num[$r-1]}_${te}_HE*03.nii.gz \
				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_Lweighted_${te}.nii.gz
		done
		r=$((${r}+1));
	done
	rm -r ${subj_outdir}/*HE00*
	
	r=1;
	while [ ${r} -le ${repeats} ]; do
	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_Lweighted_*.nii.gz
	r=$((${r}+1));
	done
	
	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_allreps_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_Lweighted_4D.nii.gz
	
	r=3;
	while [ ${r} -le ${repeats} ]; do
	fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_allreps_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_allreps_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep${r}_Lweighted_4D.nii.gz 
	r=$((${r}+1));
	done
	
	
	#### uncomment below for normal 2-rep processing...
	#for te in ${echoes[@]}; do
	#	echo te=$te
	#	fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep1_1_${rep1num1}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep1_${rep1num1}_${te}_HE -t
	#	fslsplit ${subj_outdir}/HE_betted_mcf_topup/${subject}_C_fme_pCASL_ME_rep2_1_${rep2num1}_${te}_brain_mcf_topup.nii.gz ${subj_outdir}/rep2_${rep2num1}_${te}_HE -t
	#done
	#####
	
	#echo multi-te positive\(HE1 + HE2 + HE3\) = 3c \| 2L+c \| 2L+c \|  
	#	for te in ${echoes[@]}; do
	#		fslmaths ${subj_outdir}/rep1_${rep1num1}_${te}_HE*01.nii.gz \
	#				-add ${subj_outdir}/rep1_${rep1num1}_${te}_HE*02.nii.gz \
	#				-add ${subj_outdir}/rep1_${rep1num1}_${te}_HE*03.nii.gz \
	#				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_Lweighted_${te}.nii.gz
	#		
	#		fslmaths ${subj_outdir}/rep2_${rep2num1}_${te}_HE*01.nii.gz \
	#				-add ${subj_outdir}/rep2_${rep2num1}_${te}_HE*02.nii.gz \
	#				-add ${subj_outdir}/rep2_${rep2num1}_${te}_HE*03.nii.gz \
	#				${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_Lweighted_${te}.nii.gz
	#	done
	#	rm -r ${subj_outdir}/*HE00*
	#
	#fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_rep2_Lweighted_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_Lweighted_*.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_Lweighted_*.nii.gz 
	#
	flirt -in ${subject_fslanat_dir}/T1_biascorr_brain_mask.nii.gz -ref ${subj_outdir}/BAT_brain.nii.gz -out ${subj_outdir}/T1_biascorr_brain_mask_inasl.nii.gz -applyxfm -usesqform -interp nearestneighbour
		
done
