#!/bin/sh
# takes the preprocessed ME-pCASL data (motion and distortion corrected and hadamard decoded). Runs it through oxford-asl to get perfusion. (just the first echo from TI=3100 ms. Runs calibration. (except for -div 0.85 (labelling efficiency))

echo setting paths
script_basename=$(basename $0)
script_name=$(pwd)/$0
echo script_basename is $script_basename
echo script_name is $script_name
cd /
sourcedir=/data2/DPRCX_BIDS/sourcedata
derivativesdir=/data2/DPRCX_BIDS/derivatives
decoded_betted_mcf_topup_dir=/data2/DPRCX_BIDS/derivatives/AWCBR_2023_ABSTRACT #check in this derivatives directory to re-use preprocessed data 
my_asl_calib=/data/USERS/CATHERINE/ASL_TESTING/FSL_ASL_TESTING/oxford_asl/asl_calib
topup_acquisition_parameters=/data2/USERS/tman776/scripts/my_topup_acquisition_parameters
alpha=0.85
echoes=(1 2 3 4 5 6 7)
#subject_list=$(ls $sourcedir)
cd $sourcedir
subject_list=$(find -H -maxdepth 1 -type d -name 'sub*' -printf '%f\n') #try this out
for subject in $subject_list; do
echo $subject;
done
cd /
run_name=oxasl_single_compartment_single_PLD
fslanatdir=/data2/DPRCX_BIDS/derivatives/FSL_ANAT
#force_preprocessing="FALSE" # "TRUE" or "FALSE" - n.b. this option doesnt work yet


subject_list=(
#sub-ADPRCX0019F4
#sub-ADPRCX0057F2
#sub-ADPRCX0059F2
#sub-ADPRCX0073F2  #pvcorr newmat error unless FSLANAT is rerun fresh?
#sub-ADPRCX0120F1  #pvcorr newmat error unless FSLANAT is rerun fresh
#sub-ADPRCX0174F0
#sub-ADPRCX0175F0
#sub-ADPRCX0203F0
#sub-ADPRCX0228F0
#sub-ADPRCX0121F1
#sub-ADPRCX0020F4
#sub-ADPRCX0053F2
#sub-ADPRCX0058F4
#sub-ADPRCX0075F2
#sub-ADPRCX0084F2
#sub-ADPRCX0086F2
#sub-ADPRCX0089F2
#sub-ADPRCX0090F2
#sub-ADPRCX0115F2
#sub-ADPRCX0206F0
#sub-ADPRCX0208F0
#sub-ADPRCX0219F0
#sub-ADPRCX0205F2
#sub-ADPRCX0163F2 #newmat error? #RUN 5 done 6/06/23
#sub-ADPRCX0145F2 #newmat error? #RUN 5 done 6/06/23
#) #allcontrol subjects 
) #comment-out if you want to run all subjects


for subject in ${subject_list[@]}; do
echo ${decoded_betted_mcf_topup_dir}/${subject}/decoded_betted_mcf_topup/BAT_4D.nii.gz
	if [ -e ${decoded_betted_mcf_topup_dir}/${subject}/decoded_betted_mcf_topup/BAT_4D.nii.gz ]; then
		echo ${decoded_betted_mcf_topup_dir}/${subject}/decoded_betted_mcf_topup/BAT_4D.nii.gz exists.. using preprocessed data from ${decoded_betted_mcf_topup_dir}/${subject}/decoded_betted_mcf_topup/ directory.
		
		cp -ar ${decoded_betted_mcf_topup_dir}/${subject}/decoded_betted_mcf_topup ${derivativesdir}/${subject}/asl_pilot/decoded_betted_mcf_topup
		cp -ar ${decoded_betted_mcf_topup_dir}/${subject}/topup_files ${derivativesdir}/${subject}/asl_pilot/topup_files
		cp -a ${decoded_betted_mcf_topup_dir}/${subject}/pvgm_inasl_thr05.nii.gz ${derivativesdir}/${subject}/asl_pilot/pvgm_inasl_thr05.nii.gz
		cp -a ${decoded_betted_mcf_topup_dir}/${subject}/HE_intermediate_images.tar.gz ${derivativesdir}/${subject}/asl_pilot/HE_intermediate_images.tar.gz

		cd ${decoded_betted_mcf_topup_dir}
		tar -czf ${subject}.tar ${subject}
		cd /
	fi
		topup_output_image="${derivativesdir}/${subject}/asl_pilot/topup_files/${subject}_ss_TE00_RLLR_4D_mcf_topup.nii.gz"	
		cd /
		
		if [ -d ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/ ]; then
			echo ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/ already exists... skipping this subject. 
		else
			mkdir ${derivativesdir}/${subject}/asl_pilot/BASIL_output_${run_name}/
			subj_outdir=${derivativesdir}/${subject}/asl_pilot
			logfile=$derivativesdir/${subject}/asl_pilot/DPRCX_run_oxford_asl_${run_name}
			echo DPRCX_run_oxford_asl_${run_name} > $logfile
			date | tee -a $logfile
			echo script name is $script_name > $logfile
			echo processing ${subject} | tee -a ${logfile}
			script_copy_dir=${subj_outdir}
			cp $script_name $script_copy_dir/${run_name}_${script_basename}
			cd /
		
	######################## FSL ANAT STEP ################################

			if [ -d "${fslanatdir}/${subject}/struc.anat" ]; then
			echo FSL_ANAT exists here\: "${fslanatdir}/${subject}/struc.anat/" | tee -a ${logfile}
			subject_fslanat_dir=${fslanatdir}/${subject}/struc.anat >> $logfile
		else
			echo FSL_ANAT directory does not exist. Running FSL ANAT. | tee -a ${logfile}
			/data/SOFTWARE/fsl/bin/fsl_anat -i "${sourcedir}/${subject}/anat/${subject}_T1w.nii" -o "${fslanatdir}/${subject}/struc" >> $logfile
			subject_fslanat_dir=${fslanatdir}/${subject}/struc.anat >> $logfile
		fi
		
	
		
	###################### preprocessing #######################################
			

		#-------------------------------------- PART B ----------------------------------------------------
		# START HERE:
	
		# /data2/DPRCX_BIDS/derivatives/AWCBR_2023_ABSTRACT/sub-ADPRCX0015F3/decoded_betted_mcf_topup
		# PLUCK OUT THE THIRD TI FIRST ECHO FROM REP1 AND REP2
		# AVERAGE THEM
		# INPUT RESULT TO OXFORD ASL
	
		fslsplit ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_split -t
		fslsplit ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_4D.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_split -t 
	
		mv ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_split*14.nii* ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_TI3_TE1.nii.gz
		mv ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_split*14.nii* ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE1.nii.gz
	
		rm ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep?_split*.nii*
	
		fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_TI3_TE1.nii.gz -add ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE1.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_average_TI3_TE1.nii.gz
	
		fslmaths ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_average_TI3_TE1.nii.gz -div 2 ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_average_TI3_TE1.nii.gz
		
		fslmerge -t ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_TI3_TE1.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep1_TI3_TE1.nii.gz ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_rep2_TI3_TE1.nii.gz # NOTE I changed back to using the average of the two repeats because of  a bug in Oxford ASL - it only uses the first volume if a single TI muli-repeat image volume is provided as the input.
	
		echo STEPS 7 \& 8\: oxford_asl, and asl_calib >> $logfile
	
		echo Running oxford_asl....
	

		/data/USERS/CATHERINE/ASL_TESTING/FSL_ASL_TESTING/oxford_asl/oxford_asl -i ${subj_outdir}/decoded_betted_mcf_topup/ME_pCASL_average_TI3_TE1.nii.gz --ibf=tis --iaf=diff --tis 3.10 --bolus 1.0 --casl --fslanat="${subject_fslanat_dir}" -m ${subj_outdir}/T1_biascorr_brain_mask_dil10_inasl.nii.gz --t1 1.30 --bat 1.30 --t1b 1.65 --alpha 0.85 --fixbolus --spatial --pvcorr -o "${subj_outdir}/BASIL_output_${run_name}" >> $logfile


			# Calibrate using M0.txt (arterial equilibrium magnetisation from asl_calib)
		echo ASL calib satrecovery mode ... >> $logfile
		mkdir ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/

		$my_asl_calib -c ${topup_output_image} -s ${subject_fslanat_dir}/T1_biascorr_brain.nii.gz -t ${subj_outdir}/BASIL_output_${run_name}/native_space/asl2struct.mat  --mode satrecov --te 20.54 --tis 0.5,1.7,2.9,0.5,1.7,2.9 --cgain 10 --tissref wm -m ${subj_outdir}/BASIL_output_${run_name}/native_space/wm_roi -o ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder >> $logfile


		echo calibrate using value in M0.txt \(note M0.txt is arterial equilibrium magnetisation\) >> $logfile
		
		#-div $alpha?

		fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvcorr/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_pvcorr_calib_wm_M0
	
		fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_M0
		 
		fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvgm_inasl -thr 0.5 -bin ${subj_outdir}/pvgm_inasl_thr05

		echo main outputs are: >> $logfile
			#echo Multi-TE ASL data uncalibrated:     ${subj_outdir}/${subjectdir}_C_fme_pCASL_ME_average_1_4D
		echo perfusion uncalibrated: ${subj_outdir}/BASIL_output_${run_name}/native_space/pvcorr/perfusion.nii.gz >> $logfile
			#echo perfusion calibrated:    ${subj_outdir}/perfusion_calib_wm_M0a_alpha_av
		echo Arterial equilibrium magnetisation assuming alpha 0.85: ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt >> $logfile
	
		fi
		echo Finished ${subjectdir} >> $logfile
	echo ----------------------------------------------------------------------------------------------------
done

cd /

