#!/bin/sh
# calibrate CBF map using labelling efficiency (alpha=0.85) -> ml/min/100g
subject_list=(
sub-ADPRCX0003F3 sub-ADPRCX0041F2 sub-ADPRCX0052F2 sub-ADPRCX0055F2 sub-ADPRCX0057F2 sub-ADPRCX0059F2 sub-ADPRCX0067F2 sub-ADPRCX0073F2 sub-ADPRCX0095F1 sub-ADPRCX0103F1 sub-ADPRCX0111F1 sub-ADPRCX0112F1 sub-ADPRCX0119F1 sub-ADPRCX0120F1 sub-ADPRCX0121F1 sub-ADPRCX0129F1 sub-ADPRCX0135F1 sub-ADPRCX0159F0 sub-ADPRCX0167F0 sub-ADPRCX0174F0 sub-ADPRCX0175F0 sub-ADPRCX0010F3 sub-ADPRCX0048F3 sub-ADPRCX0053F2 sub-ADPRCX0090F2 sub-ADPRCX0143F1 sub-ADPRCX0149F1 sub-ADPRCX0184F0 sub-ADPRCX0193F0 sub-ADPRCX0086F2 sub-ADPRCX0084F2 sub-ADPRCX0097F2 sub-ADPRCX0060F2 sub-ADPRCX0196F1 sub-ADPRCX0089F2 sub-ADPRCX0203F0 sub-ADPRCX0015F3 sub-ADPRCX0206F0 sub-ADPRCX0180F1 sub-ADPRCX0181F1 sub-ADPRCX0081F2 sub-ADPRCX0172F1 sub-ADPRCX0101F2 sub-ADPRCX0152F1 sub-ADPRCX0002F4 sub-ADPRCX0019F4 sub-ADPRCX0020F4 sub-ADPRCX0211F0 sub-ADPRCX0219F0 sub-ADPRCX0210F0 sub-ADPRCX0130F2 sub-ADPRCX0049F4 sub-ADPRCX0058F4 sub-ADPRCX0083F3 sub-ADPRCX0144F2 sub-ADPRCX0115F2 sub-ADPRCX0122F2 sub-ADPRCX0128F2 sub-ADPRCX0145F2 sub-ADPRCX0147F2 sub-ADPRCX0201F1 sub-ADPRCX0227F0 sub-ADPRCX0189F1 sub-ADPRCX0170F2 sub-ADPRCX0208F0 sub-ADPRCX0228F0 sub-ADPRCX0163F2 sub-ADPRCX0075F2 sub-ADPRCX0205F2 sub-ADPRCX0248F0 sub-ADPRCX0244F0 sub-ADPRCX0186F2 sub-ADPRCX0214F2 sub-ADPRCX0198F2 sub-ADPRCX0234F1
) #all subjects 

#subject_list=(sub-ADPRCX0234F1)

derivativesdir=/data2/DPRCX_BIDS/derivatives
sourcedir=/data2/DPRCX_BIDS/sourcedata
run_name=oxasl_single_compartment_single_PLD
for subject in ${subject_list[@]}; do
subject_fslanat_dir=/data2/DPRCX_BIDS/derivatives/FSL_ANAT/${subject}/struc.anat
cd /
subj_outdir=${derivativesdir}/${subject}/asl_pilot
# run on native space images
# pvc version
#fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/pvcorr/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) -div 0.85 ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_pvcorr_calib_wm_M0_alpha 
	
# non pvc version
	fslmaths ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) -div 0.85 ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_M0_alpha 
	
# run on standard space images
# pvc version
fslmaths ${subj_outdir}/BASIL_output_${run_name}/std_space/pvcorr/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) -div 0.85 ${subj_outdir}/BASIL_output_${run_name}/std_space/pvcorr/perfusion_pvcorr_calib_wm_M0_alpha 

#non-pvc version	
#	fslmaths ${subj_outdir}/BASIL_output_${run_name}/std_space/perfusion.nii.gz -mul 6000 -div $(cat ${subj_outdir}/BASIL_output_${run_name}/native_space/perfusion_calib_wm_folder/M0.txt) -div 0.85 ${subj_outdir}/BASIL_output_${run_name}/std_space/perfusion_calib_wm_M0_alpha 	
done
