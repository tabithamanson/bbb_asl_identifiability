function [Mt,Mp,Me] = my_solve_parallel_2CXM_numerical(k,TA,tau,R1p,R1e,f,kw,M0,vp,t_span,heaviside_approx)
%k is steepness of the heaviside approximation
%heaviside_approx (boolean) = 0 means just use the exact heaviside function

%run('literature_vals.m')

H_approx=@(k,t1,t0)(1./(1+exp(-k.*(t1-t0))));
%t_span=[0:10:5000];
   
[t,y]=ode113(@(t,y) diff_m(t,y,k,TA,tau,R1p,R1e,f,kw,vp,M0,H_approx,heaviside_approx),t_span,[0 0]);
    if length(t_span)==2
        Mt=vp.*y([1,end],1) + (1-vp).*y([1,end],2);
        Mp=vp.*y([1,end],1);
        Me=(1-vp).*y([1,end],2);
        t_span=t([1,end]);
    
    else
    Mt=vp.*y(:,1) + (1-vp).*y(:,2);
    Mp=vp.*y(:,1);
    Me=(1-vp).*y(:,2);
    t_span=t;
    end
    %save('my_buxton_smooth_numerical.mat','Mt','Mp','Me')
end

function dydt=diff_m(t,y,k,TA,tau,R1p,R1e,f,kw,vp,M0,H_approx,heaviside_approx)
dydt=zeros(2,1);
if heaviside_approx==1
    ma=H_approx(k,t,TA)*H_approx(k,TA+tau,t).*2.*M0.*exp(-R1p.*TA); %approximately plug-shaped bolus
else
    ma=heaviside(t-TA).*heaviside(TA+tau - t).*2.*M0.*exp(-R1p.*TA);
end
 dydt(1)=f*ma/vp-R1p*y(1)-kw*y(1);
 dydt(2)=-R1e*y(2)+ vp*kw*y(1)/(1-vp);
end
    