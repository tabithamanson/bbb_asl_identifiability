%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%parameters
repeats=2;
te=[20.84 62.52 104.2 145.88 187.56 229.24 270.92]./1000 ; %[s]
te_array=repmat(te,1,repeats);
TI_array=[1.1 2.1 3.1];
TI=TI_array;
kw_0=140/60;
R1e_0=1/1.33;
R1p=1/1.65;
R2p=1/0.080;
R2e_0=1/0.070;
vp=0.05;
tau=1.0; %bolus length
opts = optimoptions(@lsqnonlin,'Display','off','FinDiffType','central','MaxFunctionEvaluations',5000,'FunctionTolerance',1e-10,'StepTolerance',1e-10);
opts_T2e=optimoptions(@lsqnonlin,'Display','off','FinDiffType','central','MaxFunctionEvaluations',1000,'FunctionTolerance',1e-9);
alw=1.5;
mask_arterial_component=1; % boolean
mask_long_TA=1; % boolean. Mask out TA > TI voxels?
rep_subtraction_noise_floor=0; % boolean. Choose 1 to implement a noise floor based on control-control subtraction image.

% First four will have signal and model prediction plotted

subject_list={
    'sub-ADPRCX0019F4'
    'sub-ADPRCX0020F4'
    'sub-ADPRCX0053F2'
    'sub-ADPRCX0057F2'
    'sub-ADPRCX0058F4'
    'sub-ADPRCX0059F2'
    'sub-ADPRCX0073F2'
    'sub-ADPRCX0075F2'
    'sub-ADPRCX0084F2'
    'sub-ADPRCX0086F2'
    'sub-ADPRCX0089F2'
    'sub-ADPRCX0090F2'
    'sub-ADPRCX0115F2'
    'sub-ADPRCX0120F1'
    'sub-ADPRCX0121F1'
    'sub-ADPRCX0145F2'
    'sub-ADPRCX0163F2'
    'sub-ADPRCX0174F0'
    'sub-ADPRCX0175F0'
    'sub-ADPRCX0203F0'
    'sub-ADPRCX0205F2'
    'sub-ADPRCX0206F0'
    'sub-ADPRCX0208F0'
    'sub-ADPRCX0219F0'
    'sub-ADPRCX0228F0'
    };

pilot_participant=0; % is this the participant with 10 repeats?
figure('units','centimeters','Position',[0 0 8.67 8.67])
p=1; % index variable for making figure of example fits.
for s=1:length(subject_list)
    disp(char(subject_list(s)))
    %Directories
    input_dir=['/data2/DPRCX_BIDS/derivatives/' char(subject_list(s)) '/asl_pilot/'];
    output_dir=['/data2/DPRCX_BIDS/derivatives/' char(subject_list(s)) '/asl_pilot/MATLAB_output_wholeGM_RA'];
    if exist(output_dir,'dir')
        rmdir(output_dir,'s')
    end
    
    mkdir(output_dir);
    
    if ~exist(output_dir,'dir')
        mkdir(output_dir);
    end
    
    % load required images
    
    % uncomment if it's the pilot participant with 10 repeats:
    %fid=fopen(['/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot/BASIL_output_chapter_2_TM_thesis_run5/native_space/perfusion_calib_wm_folder/M0.txt'],'r');
    % otherwise:
    fid=fopen([input_dir '/BASIL_output_oxasl_single_compartment_single_PLD/native_space/perfusion_calib_wm_folder/M0.txt'],'r');
    %
    
    Moa=fscanf(fid,'%f');
    gm_mask_nii=load_untouch_nii([input_dir '/pvgm_inasl_thr05.nii.gz']);
    gm_mask_img=double(gm_mask_nii.img);
    gm_mask_img(gm_mask_img<eps)=nan;
    whole_brain_nii=load_untouch_nii([input_dir 'T1_biascorr_brain_mask_inasl.nii.gz']);
    whole_brain_nii.img=double(whole_brain_nii.img);
    
    r=1; %index variable - repeats
    if pilot_participant==1
        control_image=ones([size(whole_brain_nii.img),15,5]);
        for i=2:2:10 % FOR PILOT PARTICIPANT ONLY (control images are in a different format):
            rep1_control_ims_nii=load_untouch_nii([input_dir '/decoded_betted_mcf_topup/ME_pCASL_rep' num2str(i) '_Lweighted_4D.nii.gz']);
            rep2_control_ims_nii=load_untouch_nii([input_dir '/decoded_betted_mcf_topup/ME_pCASL_rep' num2str(i-1) '_Lweighted_4D.nii.gz']);
            % make it the right shape (5D)
            control_image(:,:,:,1:7,r)=rep1_control_ims_nii.img(:,:,:,:).*whole_brain_nii.img;
            control_image(:,:,:,8:14,r)=rep2_control_ims_nii.img(:,:,:,:).*whole_brain_nii.img;
            r=r+1;
        end
        TA_thr_nii=load_untouch_nii(['/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot/BASIL_output_chapter_2_TM_thesis_run5/native_space/pvcorr/arrival.nii.gz']);
        TA_thr_nii.img=TA_thr_nii.img.*gm_mask_img;
        CBF_nii=load_untouch_nii(['/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot/BASIL_output_chapter_2_TM_thesis_run5/native_space/perfusion_pvcorr_calib_wm_M0.nii.gz']);
        CBF_nii.img=CBF_nii.img.*gm_mask_img;
    else
        control_ims_nii=load_untouch_nii([input_dir '/decoded_betted_mcf_topup/ME_pCASL_allreps_Lweighted_4D.nii.gz']);
        control_image_4D=control_ims_nii.img;
        % make it the right shape (5D)
        for i=1:repeats
            control_image(:,:,:,:,i)=(control_image_4D(:,:,:,(i-1)*7+1:(i-1)*7+7)).*whole_brain_nii.img;
        end
        TA_thr_nii=load_untouch_nii([input_dir '/BASIL_output_oxasl_single_compartment/native_space/pvcorr/arrival.nii.gz']);
        TA_thr_nii.img=TA_thr_nii.img.*gm_mask_img;
        CBF_nii=load_untouch_nii([input_dir 'BASIL_output_oxasl_single_compartment_single_PLD/native_space/perfusion_pvcorr_calib_wm_M0_alpha.nii.gz']);
        CBF_nii.img=CBF_nii.img.*gm_mask_img;
    end
    
    TA_matrix = double(TA_thr_nii.img .*gm_mask_img);
    f_matrix = double((CBF_nii.img)./(60*100)); %convert to ml/s ml
    
    if mask_long_TA==1
        TA_TI_mask=ones(size(gm_mask_nii.img)).*nan;
    else
        TA_TI_mask=ones(size(gm_mask_nii.img));
    end
    
    % Load multi-echo data for each TI for each repeat
    for i=1:repeats
        ASL_image = [input_dir '/decoded_betted_mcf_topup/ME_pCASL_rep' num2str(i) '_4D.nii.gz'];
        ASL_nii=load_untouch_nii(ASL_image);
        ASL_img(:,:,:,:,i)=double(ASL_nii.img);
    end
    
    ASL_img(ASL_img<eps)=nan;
    
    %% prepare ASL image: split into TIs and average
    ASL_img_all=ASL_img;
    
    ASL_img_all_TI1=ASL_img_all(:,:,:,1:7,:);
    ASL_img_all_TI2=ASL_img_all(:,:,:,8:14,:);
    ASL_img_all_TI3=ASL_img_all(:,:,:,15:21,:);
    
    ASL_img_all_TI1=reshape(ASL_img_all_TI1,size(ASL_img_all_TI1,1),size(ASL_img_all_TI1,2),size(ASL_img_all_TI1,3),7*repeats);
    ASL_img_all_TI2=reshape(ASL_img_all_TI2,size(ASL_img_all_TI1));
    ASL_img_all_TI3=reshape(ASL_img_all_TI3,size(ASL_img_all_TI1));
    
    
    ASL_img_average=mean(ASL_img_all,5,'omitnan');
    
    ASL_img_average_TI1=ASL_img_average(:,:,:,1:7);
    ASL_img_average_TI2=ASL_img_average(:,:,:,8:14);
    ASL_img_average_TI3=ASL_img_average(:,:,:,15:21);
    
    %% Arterial masking
    not_arterial_mask=ones(size(gm_mask_img)); %pre-allocate. 1 is non-arterial, nan will be arterial.
    
    if mask_arterial_component
        % create mask
        ASL_img_average_TI1_TE1=ASL_img_average_TI1(:,:,:,1).*whole_brain_nii.img;
        signal_threshold=quantile(reshape(ASL_img_average_TI1_TE1(ASL_img_average_TI1_TE1>eps),[],1),0.95);
        not_arterial_mask(ASL_img_average_TI1_TE1>signal_threshold)=nan;
        
        not_arterial_mask_nii = gm_mask_nii;
        not_arterial_mask_nii.img = not_arterial_mask;
        save_untouch_nii(not_arterial_mask_nii,[output_dir '/not_arterial_mask_nii.nii']);
        % apply mask
        
        ASL_img_all_TI1=ASL_img_all(:,:,:,1:7,:).*not_arterial_mask;
        ASL_img_average_TI1=ASL_img_average(:,:,:,1:7).*not_arterial_mask;
        
        ASL_img_all_TI2=ASL_img_all(:,:,:,8:14,:).*not_arterial_mask;
        ASL_img_average_TI2=ASL_img_average(:,:,:,8:14).*not_arterial_mask;
        
        
        ASL_img_all_TI3=ASL_img_all(:,:,:,15:21,:).*not_arterial_mask;
        ASL_img_average_TI3=ASL_img_average(:,:,:,15:21).*not_arterial_mask;
        
    end
    
    %% Estimate noise floor
    
    if rep_subtraction_noise_floor==1
        % Calculate noise floor
        % now subtract repeat 2 - repeat 1
        j=1; % index variable
        for r=2:2:repeats
            subtraction_image(:,:,:,:,j)= double(ASL_img(:,:,:,:,r)- ASL_img(:,:,:,:,r-1));
        end
        subtraction_image_masked=abs(subtraction_image.*gm_mask_img);
        %gm_mean_noise=squeeze(mean(subtraction_image_masked,[1 2 3],'omitnan'));
        noise_floor=squeeze(mean(subtraction_image_masked,[1 2 3],'omitnan')).';
        %noise_floor=repmat(noise_floor.',1,repeats); % make it long
    else
        noise_floor=eps.*ones(1,length(te).*length(TI_array));
    end
    
    %% Mask out voxels where TA > TI
    if mask_long_TA==1
        
        TA_TI_mask_TI1=TA_TI_mask;
        TA_TI_mask_TI1(TA_thr_nii.img<TI_array(1))=gm_mask_img(TA_thr_nii.img<TI_array(1));
        ASL_img_all_TI1=ASL_img_all(:,:,:,1:7,:).*TA_TI_mask_TI1.*not_arterial_mask;
        ASL_img_average_TI1=ASL_img_average(:,:,:,1:7).*TA_TI_mask_TI1.*not_arterial_mask;
        
        TA_TI_mask_TI2=TA_TI_mask;
        TA_TI_mask_TI2(TA_thr_nii.img<TI_array(2))=gm_mask_img(TA_thr_nii.img<TI_array(2));
        ASL_img_all_TI2=ASL_img_all(:,:,:,8:14,:).*TA_TI_mask_TI2.*not_arterial_mask;
        ASL_img_average_TI2=ASL_img_average(:,:,:,8:14).*TA_TI_mask_TI2.*not_arterial_mask;
        
        TA_TI_mask_TI3=TA_TI_mask;
        TA_TI_mask_TI3(TA_thr_nii.img<TI_array(3))=gm_mask_img(TA_thr_nii.img<TI_array(3));
        ASL_img_all_TI3=ASL_img_all(:,:,:,15:21,:).*TA_TI_mask_TI3.*not_arterial_mask;
        ASL_img_average_TI3=ASL_img_average(:,:,:,15:21).*TA_TI_mask_TI3.*not_arterial_mask;
        
        TA_TI_mask_TI1_nii=gm_mask_nii;
        TA_TI_mask_TI1_nii.img=TA_TI_mask_TI1;
        save_untouch_nii(TA_TI_mask_TI1_nii, [output_dir '/TA_TI_mask_TI1.nii']);
        TA_TI_mask_TI2_nii=gm_mask_nii;
        TA_TI_mask_TI2_nii.img=TA_TI_mask_TI2;
        save_untouch_nii(TA_TI_mask_TI2_nii, [output_dir '/TA_TI_mask_TI2.nii']);
        TA_TI_mask_TI3_nii=gm_mask_nii;
        TA_TI_mask_TI3_nii.img=TA_TI_mask_TI3;
        save_untouch_nii(TA_TI_mask_TI3_nii, [output_dir '/TA_TI_mask_TI3.nii']);
        
        ASL_img_all_TI1=reshape(ASL_img_all_TI1,size(ASL_img_all_TI1,1),size(ASL_img_all_TI1,2),size(ASL_img_all_TI1,3),7*repeats);
        ASL_img_all_TI2=reshape(ASL_img_all_TI2,size(ASL_img_all_TI2,1),size(ASL_img_all_TI2,2),size(ASL_img_all_TI2,3),7*repeats);
        ASL_img_all_TI3=reshape(ASL_img_all_TI3,size(ASL_img_all_TI1,1),size(ASL_img_all_TI1,2),size(ASL_img_all_TI1,3),7*repeats);
        
    else
        TA_TI_mask_TI1=gm_mask_img;
        TA_TI_mask_TI2=gm_mask_img;
        TA_TI_mask_TI3=gm_mask_img;
    end
    
    noise_floor_TI1=noise_floor(1:7);
    noise_floor_TI2=noise_floor(8:14);
    noise_floor_TI3=noise_floor(15:21);
    
    %% pre-allocate matrices for fitted values
    
    S0_T2e_matrix=ones(size(gm_mask_img)).*nan;
    T2e_matrix=ones(size(gm_mask_img)).*nan;
    rmse_T2e_matrix=ones(size(gm_mask_img)).*nan;
    exitflag_T2e_matrix=ones(size(gm_mask_img)).*nan;
    
    
    kw_TI1_matrix=ones(size(gm_mask_img)).*nan;
    kw_TI2_matrix=ones(size(gm_mask_img)).*nan;
    kw_TI3_matrix=ones(size(gm_mask_img)).*nan;
    
    R1e_TI1_matrix=ones(size(gm_mask_img)).*nan;
    R1e_TI2_matrix=ones(size(gm_mask_img)).*nan;
    R1e_TI3_matrix=ones(size(gm_mask_img)).*nan;
    
    R2e_TI1_matrix=ones(size(ASL_img_all_TI1)).*nan;
    R2e_TI2_matrix=ones(size(ASL_img_all_TI2)).*nan;
    R2e_TI3_matrix=ones(size(ASL_img_all_TI3)).*nan;
    
    rmse_TI1_matrix=ones(size(gm_mask_img)).*nan;
    exitflag_TI1_matrix=ones(size(gm_mask_img)).*nan;
    rmse_TI2_matrix=ones(size(gm_mask_img)).*nan;
    exitflag_TI2_matrix=ones(size(gm_mask_img)).*nan;
    rmse_TI3_matrix=ones(size(gm_mask_img)).*nan;
    exitflag_TI3_matrix=ones(size(gm_mask_img)).*nan;
    
    
    %% T2e gm fit
    
    control_img_average=mean(control_image,5); %average over all repeats
    
    gm_data_R2e=double(squeeze(mean(control_img_average.*gm_mask_img,[1 2 3],'omitnan')));
    x0=[gm_data_R2e(1),R2e_0,0];
    [x_fit,~,residuals,exitflag]=...
        lsqnonlin(@(x) (log((x(1).*exp(-te.*x(2))) + x(3) +1) - log(gm_data_R2e.'+1)),x0,[0 0 0],[],opts_T2e);
    S0_R2e_gm = x_fit(1);
    R2e_gm = x_fit(2);
    c_R2e_gm = x_fit(3);
    rmse_R2e_gm=sqrt(mean((residuals).^2));
    re_R2e_gm=mean(abs(residuals)./gm_data_R2e.');
    exitflag_R2e_gm=exitflag;
    
    % figure
    % plot(te, gm_data_R2e,'x','LineWidth', alw);
    % ylabel('signal [A.U.]')
    % xlabel('echo time [s]')
    % hold on
    % plot(te, S0_R2e_gm.*exp(-te.*R2e_gm)+c_R2e_gm,'k-')
    % alw = 1.5;    % AxesLineWidth
    % fsz = 12;      % Fontsize
    % set(gca, 'FontSize', fsz, 'LineWidth', alw);
    % title('Whole GM T2_e fit')
    % hold off
    
    %% kw fit whole GM
    % whole gm average fit:
    
    x0=[kw_0 R1e_0]; % initial values
    
    % apply any masks:
    TA_TI1=mean(TA_matrix.*TA_TI_mask_TI1,'all','omitnan');
    f_TI1=mean(f_matrix.*TA_TI_mask_TI1,'all','omitnan');
    ASL_img_all_TI1(:,:,:,:)=ASL_img_all_TI1(:,:,:,:).*gm_mask_img.*TA_TI_mask_TI1;
    gm_data_TI1=double(squeeze(mean(ASL_img_all_TI1,[1 2 3],'omitnan'))).';
    data_include_TI1=find(gm_data_TI1>repmat(noise_floor_TI1,1,repeats));
    
    TA_TI2=mean(TA_matrix.*TA_TI_mask_TI2,'all','omitnan');
    f_TI2=mean(f_matrix.*TA_TI_mask_TI2,'all','omitnan');
    ASL_img_all_TI2(:,:,:,:)=ASL_img_all_TI2(:,:,:,:).*gm_mask_img.*TA_TI_mask_TI2;
    gm_data_TI2=double(squeeze(mean(ASL_img_all_TI2,[1 2 3],'omitnan'))).';
    data_include_TI2=find(gm_data_TI2>repmat(noise_floor_TI2,1,repeats));
    
    TA_TI3=mean(TA_matrix.*TA_TI_mask_TI3,'all','omitnan');
    f_TI3=mean(f_matrix.*TA_TI_mask_TI3,'all','omitnan');
    ALL_img_all_TI3(:,:,:,:)=ASL_img_all_TI3(:,:,:,:).*gm_mask_img.*TA_TI_mask_TI3;
    gm_data_TI3=double(squeeze(mean(ASL_img_all_TI3,[1 2 3],'omitnan'))).'; % SHOULD THIS BE ASL_img_all_TI3 or ASL_img_average_TI3
    data_include_TI3=find(gm_data_TI3>repmat(noise_floor_TI3,1,repeats));
    
    data_include=[data_include_TI1 data_include_TI2 data_include_TI3];
    
    % prepare t_array:
    te_array_full=[te_array te_array te_array];
    t_array = [TI_array(1) + te, TI_array(2) + te, TI_array(3) + te];
    t_array_TI1=[TI(1)+te];
    t_array_TI2=[TI(2)+te];
    t_array_TI3=[TI(3)+te];
    
    % line up data in the right format:
    gm_data=[gm_data_TI1(1:7) gm_data_TI2(1:7) gm_data_TI3(1:7) gm_data_TI1(8:14) gm_data_TI2(8:14) gm_data_TI3(8:14)];
    
    % Model:
    model_func=@(x)repmat([heaviside(t_array_TI1 - TA_TI1).*(heaviside(t_array_TI1-TI(1)).*heaviside(TI(2)-t_array_TI1).*my_solve_parallel_2CXM_T2_numerical(100,TA_TI1,tau,R1p,x(2),R2p,R2e_gm,f_TI1,x(1),Moa.*0.85,vp,TI(1)+te,TI(1),0)),...
        heaviside(t_array_TI2 - TA_TI2).*(heaviside(t_array_TI2-TI(2)).*heaviside(TI(3)-t_array_TI2).*my_solve_parallel_2CXM_T2_numerical(100,TA_TI2,tau,R1p,x(2),R2p,R2e_gm,f_TI2,x(1),Moa.*0.85,vp,TI(2)+te,TI(2),0)),...
        heaviside(t_array_TI3 - TA_TI3).*(heaviside(t_array_TI3-TI(3)).*my_solve_parallel_2CXM_T2_numerical(100,TA_TI3,tau,R1p,x(2),R2p,R2e_gm,f_TI3,x(1),Moa.*0.85,vp,TI(3)+te,TI(3),0))],1,repeats);
    
    objective_function = @(x)log(model_func(x) +1) - log(gm_data+1);
    
    % kw fitting step:
    [x_fit,~,residuals,exitflag]=...
        lsqnonlin(objective_function,[x0],[0 R1e_0],[+Inf R1e_0],opts);
    kw_gm = x_fit(1);
    R1e_gm = x_fit(2);
    
    rmse_kw_gm=sqrt(mean((residuals).^2));
    re_kw_gm=mean(abs(residuals)./log(gm_data+1));
    exitflag_kw_gm=exitflag;
    
    model_output=model_func(x_fit);
    rep1_model_output=model_output(1:21);
    
    % fit examples (first four participants)
    if p<5
        subplot(2,2,p)
        plot([t_array_TI1 t_array_TI2 t_array_TI3 t_array_TI1 t_array_TI2 t_array_TI3],gm_data,'o','LineWidth',1.5)
        hold on
        ylim([0 40])
        plot([t_array_TI1], rep1_model_output(1:7), 'k-','LineWidth',1.5)
        hold on
        ylim([0 40])
        plot([t_array_TI2], rep1_model_output(8:14), 'k-','LineWidth',1.5)
        hold on
        ylim([0 40])
        plot([t_array_TI3], rep1_model_output(15:21), 'k-','LineWidth',1.5)
        ylim([0 40])
        xlabel('time (s)')
        ylabel('signal (AU)')
        p=p+1;
    end
    
    % UNCOMMENT TO SAVE RESULTS:
    % save([output_dir  '/matlab_workspace_fit_kw_GM_RA_R1tfixed_T1p165_T2p80']);
    
    
    TA_mean(s)=mean(TA_thr_nii.img,'all','omitnan');
    CBF_mean(s)=mean(CBF_nii.img,'all','omitnan');
    Moa_gm(s)=Moa;
    T2e_gm_all(s)=1/R2e_gm;
    T2p_gm_all(s)=1/R2p;
    T1e_gm_all(s)=1/R1e_gm;
    kw_gm_all(s)=kw_gm.*60;
    re(s)=re_kw_gm;
    exitflag_gm(s)=exitflag_kw_gm;
    re_T2e(s)=re_R2e_gm;
    exitflag_T2e(s)=exitflag_R2e_gm;
end
% Display results:
format shortEng
disp(['f ','TA ','kw ','T1e ','T2e ','Moa ','rmse ','exitflag ', 'rmse_T2e','exitflag_T2e'])
disp([CBF_mean.', TA_mean.', kw_gm_all.', T1e_gm_all.', T2e_gm_all.', Moa_gm.', re.',exitflag_gm.',T2p_gm_all.',re_T2e.',exitflag_T2e.'])