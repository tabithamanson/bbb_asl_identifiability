% tSNR and noise vs signal magnitude calculation (whole GM)
% Inputs are the 10-repeat participant's nifti Hadamard-decoded images &
% their oxford_asl outputs


% with smoothing
repeats=10;
subject_dir='/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot';
GM_mask_image='/data2/DPRCX_PILOT/derivatives/tabitha_processing/sub-DPRCXPILOT14/asl_pilot/BASIL_output_chapter_2_TM_thesis_run5/native_space/gm_mask.nii.gz';
GM_mask_image_loaded=load_untouch_nii(GM_mask_image);
GM_mask_image_loaded.img(GM_mask_image_loaded.img==0)=nan;
rep_numbers=(1:10);
te_numbers=(1:7);
TI_numbers=(1:3);
%control_series_numbers=(22:6:82); % hardcoded this



for n=1:length(rep_numbers)
    for m=1:length(TI_numbers)
        for l=1:length(te_numbers)
            image_dir=[subject_dir '/decoded_betted_mcf_topup/ME_pCASL_rep' num2str(rep_numbers(n)) '_4D.nii.gz'];
            image=load_untouch_nii(image_dir);
            image_masked_rep(:,:,:,:,n)=double(image.img).*double(GM_mask_image_loaded.img);
        end
    end
end

transform=0;
prior_smoothing=0; % 
%Filter images
if prior_smoothing
    FWHM = 8; %mm
    voxel_size_x = 1.981; %mm
    voxel_size_y = 2; %mm
    voxel_size_z = 4; %mm
    sigma_setting = [(FWHM/voxel_size_x)/(2.*sqrt(2*log(2))) (FWHM/voxel_size_y)/(2.*sqrt(2*log(2))) (FWHM/voxel_size_z)/(2.*sqrt(2*log(2)))]; %Numerator is FWHM
    filtwidth = [3 3];
    imagefilter=fspecial('gaussian',filtwidth,sigma_setting(1)); %convolve them datafiltered = imfilter(rfvals,imagefilter,'symmetric','conv');
    
    %ASL data:
    for j = 1:size(image_masked_rep,5)
        for k = 1:size(image_masked_rep,4)
            for z = 1:size(image_masked_rep,3)
                %ASL_raw_smoothed_matrix(:,:,z,k) = nanconvn(ASL_image_raw_loaded.img(:,:,z,k),imagefilter,'edge','nanout');
                image_masked_rep(:,:,z,k,j)=nanconvn(image_masked_rep(:,:,z,k,j),imagefilter,'edge','nanout');
            end
        end
    end
    
end
%         for z = 1:size(ASL_image_loaded.img,3)
%             TA_matrix(:,:,z) = nanconvn(TA_image_loaded.img(:,:,z),imagefilter,'edge','nanout').* GM_mask_image_loaded.img(:,:,z);
%             f_matrix(:,:,z) = nanconvn(f_image_loaded.img(:,:,z),imagefilter,'edge','nanout').* GM_mask_image_loaded.img(:,:,z);
%             R1e_matrix(:,:,z) = nanconvn(R1e_matrix(:,:,z),imagefilter,'edge','nanout').* GM_mask_image_loaded.img(:,:,z);
%         end


if transform
    image_masked_rep=log(0.5*(image_masked_rep)+1);
end
    
    voxelwise_mean=mean(double(image_masked_rep),5,'omitnan','double');
    voxelwise_std=std(double(image_masked_rep),0,5,'omitnan'); %sample standard deviation
    GM_mean=mean(double(image_masked_rep),[1 2 3 5],'omitnan','double');
    GM_std=std(double(mean(image_masked_rep,[1 2 3],'omitnan')),0,5,'omitnan');
    
    GM_mean_reps=mean(double(image_masked_rep),[1 2 3],'omitnan','double'); % for estimating noise floor
    GM_mean_reps=squeeze(GM_mean_reps);
    j=1;
    for i=2:2:10
       GM_mean_reps_diff(:,j)=GM_mean_reps(:,i)-GM_mean_reps(:,i-1);
       j=j+1;
    end
    
    GM_tSNR=GM_mean./GM_std;
    GM_variance = GM_std.^2;

    
    for i = 1:21
        mean_signal_array(i)=GM_mean(1,1,1,i);
        mean_tSNR_array(i)=GM_tSNR(1,1,1,i);
        mean_std_array(i)=GM_std(1,1,1,i);
    end
% end
te = [20.84 62.52 104.2 145.88 187.56 229.24 270.92]./1000 ; %[s]
    TI= [1100 2100 3100]./1000;
    t = [TI(1).*ones(size(te)) + te, TI(2).*ones(size(te)) + te, TI(3).*ones(size(te)) + te];

    fsz=12;
    alw=2;
figure('units', 'centimeters', 'position',[0 0 2*8.67 4*8.67/3])
subplot(2,1,1)
plot(t,mean_signal_array,'x');
xlabel('t [s]')
ylabel('signal [AU]')
set(gca, 'FontSize', fsz, 'LineWidth', alw)
%title('mean signal over 10 repeats')
subplot(2,1,2)
plot(t,mean_tSNR_array,'x');
xlabel('t [s]')
ylabel('tSNR')
set(gca, 'FontSize', fsz, 'LineWidth', alw)

mean_tSNR_array.'
mean_std_array.'

figure('units', 'centimeters', 'position',[0 0 2*8.67 4*8.67/3])
mdl=fitlm(log(mean_signal_array), log(mean_std_array.^2))
f1=plot(mdl,'LineWidth', alw)
f1(1).LineWidth=2;
f1(2).LineWidth=2;
f1(3).LineWidth=2;
f1(4).LineWidth=2;
f1(2).DisplayName = 'ln($\sigma^2$)=1.3ln($\overline{\Delta M}$)-3.4';
f1(3).DisplayName = '95% confidence bounds';
xlabel('ln($\overline{\Delta M}$)','Interpreter','latex')
ylabel('ln($\sigma^2$)','Interpreter','latex')
set(gca, 'FontSize', fsz, 'LineWidth', alw)





