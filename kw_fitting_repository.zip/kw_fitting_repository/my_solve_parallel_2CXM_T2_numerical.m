function [Mt,Mp,Me,Mt0,Mp0,Me0] = my_solve_parallel_2CXM_T2_numerical(k,TA,tau,R1p,R1e,R2p,R2e,f,kw,M0,vp,t_array,TI_array,heaviside_approx)
%k is steepness of the heaviside approximation
%heaviside_approx (boolean) = 0 means just use the exact heaviside function

%run('literature_vals.m')

% load("parallel_2CXM.mat")
% t=2100;
%  Mp0=double(subs(Mp));
%  Me0=double(subs(Me));

H_approx=@(k,t1,t0)(1./(1+exp(-k.*(t1-t0))));
%t_span=[0:10:5000]
num_echoes=length(t_array)/length(TI_array);
    for i=1:length(TI_array)
        
        %t_array=ones(length(t_span)).*TI_array(i) + te_span;
        T1time=(0:1:5100)./1000; % 0:10:5100 used for first two body chapters in thesis, 0:1:5100 used for last chapter
        ind0=find(abs(T1time-TI_array(i))<1e-12);
        %Mt_numerical_k01 = my_solve_parallel_2CXM_numerical(0.1,TA,tau,R1p,R1e,f,kw,M0,t_span,1);
        [Mt0,Mp0,Me0]=my_solve_parallel_2CXM_numerical(k,TA,tau,R1p,R1e,f,kw,M0,vp,[0:1:5100]./1000, heaviside_approx);
        Mt0=Mp0(ind0)+Me0(ind0);
        Mp0=Mp0(ind0);
        Me0=Me0(ind0);
        
        [t,y]=ode113(@(t,y) diff_m(t,y,k,TA,tau,R1p,R1e,R2p,R2e,f,kw,vp,M0,H_approx,heaviside_approx),[TI_array(i) t_array((i-1)*num_echoes+1:(i)*num_echoes)],[Mp0./vp,Me0./(1-vp)]);
        
            Mt((i-1)*num_echoes+1:(i)*num_echoes)=vp.*y([2:end],1) + (1-vp).*y([2:end],2);
            Mp((i-1)*num_echoes+1:(i)*num_echoes)=vp.*y([2:end],1);
            Me((i-1)*num_echoes+1:(i)*num_echoes)=(1-vp).*y([2:end],2);
        
%         [t,y]=ode113(@(t,y) diff_m(t,y,k,TA,tau,R1p,R1e,R2p,R2e,f,kw,vp,M0,H_approx,heaviside_approx),t_array((i-1)*num_echoes+1:(i)*num_echoes),[Mp0./vp,Me0./(1-vp)]);
%         
%             Mt((i-1)*num_echoes+1:(i)*num_echoes)=vp.*y(:,1) + (1-vp).*y(:,2);
%             Mp((i-1)*num_echoes+1:(i)*num_echoes)=vp.*y(:,1);
%             Me((i-1)*num_echoes+1:(i)*num_echoes)=(1-vp).*y(:,2);
            
    end

    %save('my_buxton_smooth_numerical.mat','Mt','Mp','Me')
end

function dydt=diff_m(t,y,k,TA,tau,R1p,R1e,R2p,R2e,f,kw,vp,M0,H_approx,heaviside_approx)
dydt=zeros(2,1);
% if heaviside_approx==1
%     ma=H_approx(k,t,TA)*H_approx(k,TA+tau,t).*2.*M0.*exp(-R1p.*TA); %approximately plug-shaped bolus
% else
%     ma=heaviside(t-TA).*heaviside(TA+tau - t).*2.*M0.*exp(-R1p.*TA);
% end
ma=0;
 dydt(1)=-((kw*vp).*y(1) + vp.*R2p.*y(1))./vp;
 dydt(2)=((kw*vp).*y(1) - (1-vp).*R2e.*y(2))./(1-vp);
end
    